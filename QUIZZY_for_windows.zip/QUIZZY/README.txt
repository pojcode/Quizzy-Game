--- CREDITS -----------------------------------------------------------------------


        · Game name ---- Quizzy

        · Version ---- v2.0

        · Author ---- Pablo Ortega

        · Year ---- 2021

        · Code lenguage ---- Python



--- INFO --------------------------------------------------------------------------


· Questions:

        You can add your own questions editing the quizzy_questions.txt 
	inside quizzy_data folder.
        To do it just add your question and answer with the following format:

        question; wrong_answer; wrong_answer; wrong_answer; correct_answer

        One question per line. Save the file. Enjoy!!


· Files:

        QUIZZY, quizzy_files and quizzy_data MUST BE in the SAME directory.